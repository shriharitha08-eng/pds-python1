# Food Distribution & PDS Analytics System

A full-stack Django web application for analysing India's Public Distribution System (PDS) data.

## Tech Stack
- **Backend**: Django 6 (Python)
- **Frontend**: HTML5, CSS3 (custom blue/white theme)
- **Data Processing**: Pandas, NumPy
- **Visualisation**: Matplotlib (base64-embedded charts)
- **Database**: SQLite (default)

## Setup Instructions

### 1. Install dependencies
```bash
pip install django pandas numpy matplotlib pillow
```

### 2. Run migrations
```bash
cd pds_project_root
python manage.py makemigrations
python manage.py migrate
```

### 3. Create superuser (optional)
```bash
python manage.py createsuperuser
```

### 4. Start the server
```bash
python manage.py runserver
```

### 5. Open in browser
```
http://127.0.0.1:8000/
```

## Features
- Role-based auth (Admin / User)
- 4 analytical dashboards with Matplotlib charts
- Admin CSV upload with auto data cleaning
- CSV report downloads
- State-wise and year-wise filters
- Summary statistics (mean, median, std)
- Predictive demand forecast (NumPy linear regression)

## Sample Data
Use `sample_pds_data.csv` to test the Admin upload feature.

## Project Structure
```
pds_project_root/
├── pds_project/         # Django project settings & URLs
├── analytics/           # Main app
│   ├── models.py        # UserProfile, UploadedDataset
│   ├── views.py         # All views
│   ├── urls.py          # URL routing
│   ├── data_utils.py    # Pandas/NumPy/Matplotlib utilities
│   └── templates/       # HTML templates
├── static/css/style.css # Global stylesheet
├── media/               # Uploaded & processed files
└── sample_pds_data.csv  # Sample dataset
```
