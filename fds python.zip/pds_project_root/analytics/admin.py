from django.contrib import admin
from .models import UserProfile, UploadedDataset

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'role']

@admin.register(UploadedDataset)
class UploadedDatasetAdmin(admin.ModelAdmin):
    list_display = ['dataset_type', 'uploaded_by', 'row_count', 'uploaded_at']
