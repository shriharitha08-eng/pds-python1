"""
Data processing utilities for PDS Analytics.
Datasets: 1000+ rows, 15+ columns each.
"""
import io
import base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

BLUE = '#1a73e8'
LIGHT_BLUE = '#4fc3f7'
RED = '#e53935'
GREEN = '#43a047'
ORANGE = '#fb8c00'
PURPLE = '#8e24aa'
BG = '#f8faff'

STATES = [
    'Uttar Pradesh','Maharashtra','Bihar','West Bengal','Madhya Pradesh',
    'Rajasthan','Tamil Nadu','Karnataka','Gujarat','Andhra Pradesh',
    'Odisha','Telangana','Kerala','Jharkhand','Assam',
    'Punjab','Haryana','Chhattisgarh','Uttarakhand','Himachal Pradesh',
    'Delhi','Jammu & Kashmir','Goa','Tripura','Meghalaya',
    'Manipur','Nagaland','Arunachal Pradesh','Mizoram','Sikkim',
    'Chandigarh','Puducherry','Dadra & NH','Lakshadweep','Andaman & Nicobar',
    'Ladakh',
]

DISTRICTS_PER_STATE = 28   # 36 states × 28 districts ≈ 1008 rows

def _fig_to_b64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight', dpi=110, facecolor=BG)
    buf.seek(0)
    encoded = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    return encoded


# ── Rich dataset generators (1000+ rows, 15+ columns) ────────────────────────

def get_pds_data():
    """PDS district-level dataset — 1008 rows × 16 columns."""
    np.random.seed(42)
    rows = []
    for state in STATES:
        pop_base = np.random.randint(5, 220)
        for d in range(1, DISTRICTS_PER_STATE + 1):
            allocated = np.random.randint(200, 2000)
            distributed = int(allocated * np.random.uniform(0.65, 0.98))
            population = np.random.randint(1, 30)
            bpl_pct = round(np.random.uniform(8, 48), 1)
            apl_pct = round(100 - bpl_pct, 1)
            ration_shops = np.random.randint(50, 800)
            beneficiaries = np.random.randint(5000, 500000)
            wheat_alloc = int(allocated * np.random.uniform(0.4, 0.6))
            rice_alloc = allocated - wheat_alloc
            wheat_dist = int(wheat_alloc * np.random.uniform(0.7, 1.0))
            rice_dist = int(rice_alloc * np.random.uniform(0.7, 1.0))
            year = np.random.choice(range(2018, 2024))
            rows.append({
                'State': state,
                'District': f"{state[:4]}_D{d:02d}",
                'Year': year,
                'Allocated_MT': allocated,
                'Distributed_MT': distributed,
                'Wheat_Allocated_MT': wheat_alloc,
                'Rice_Allocated_MT': rice_alloc,
                'Wheat_Distributed_MT': wheat_dist,
                'Rice_Distributed_MT': rice_dist,
                'Population_M': population,
                'BPL_Percentage': bpl_pct,
                'APL_Percentage': apl_pct,
                'Ration_Shops': ration_shops,
                'Beneficiaries': beneficiaries,
                'Surplus_Deficit': allocated - distributed,
                'Per_Capita_kg': round(distributed * 1000 / max(population * 1e6, 1) * 1000, 2),
            })
    df = pd.DataFrame(rows)
    return df


def get_fci_data():
    """FCI monthly stock dataset — 1080 rows × 15 columns."""
    np.random.seed(7)
    rows = []
    for state in STATES:
        for year in range(2015, 2025):
            for month in range(1, 13):
                stock = round(np.random.uniform(10, 90), 2)
                capacity = round(np.random.uniform(70, 120), 2)
                wastage_pct = round(np.random.uniform(1.0, 6.5), 2)
                wastage_mt = round(stock * wastage_pct / 100, 2)
                procurement = round(np.random.uniform(5, 50), 2)
                offtake = round(np.random.uniform(5, 45), 2)
                wheat_stock = round(stock * np.random.uniform(0.4, 0.6), 2)
                rice_stock = round(stock - wheat_stock, 2)
                transit_loss = round(np.random.uniform(0.1, 2.0), 2)
                storage_loss = round(wastage_mt - transit_loss if wastage_mt > transit_loss else 0.1, 2)
                utilisation_pct = round(min(stock / capacity * 100, 100), 1)
                rows.append({
                    'State': state,
                    'Year': year,
                    'Month': month,
                    'Stock_MT': stock,
                    'Storage_Capacity_MT': capacity,
                    'Procurement_MT': procurement,
                    'Offtake_MT': offtake,
                    'Wheat_Stock_MT': wheat_stock,
                    'Rice_Stock_MT': rice_stock,
                    'Wastage_MT': wastage_mt,
                    'Wastage_Pct': wastage_pct,
                    'Transit_Loss_MT': transit_loss,
                    'Storage_Loss_MT': storage_loss,
                    'Utilisation_Pct': utilisation_pct,
                    'Net_Available_MT': round(stock - wastage_mt, 2),
                })
    df = pd.DataFrame(rows)
    return df


def get_census_data():
    """Census district-level dataset — 1008 rows × 15 columns."""
    np.random.seed(21)
    # Realistic per-capita food need: ~200kg/year = 0.2 MT per person
    # population in millions, so threshold = population_M * 1e6 * 0.2 / 1000 = population_M * 200
    rows = []
    for state in STATES:
        for d in range(1, DISTRICTS_PER_STATE + 1):
            population = np.random.randint(1, 30)  # millions
            # food_supply in MT: realistic range around the threshold
            food_supply = int(population * np.random.uniform(150, 350))
            bpl_pct = round(np.random.uniform(8, 48), 1)
            literacy = round(np.random.uniform(55, 95), 1)
            urban_pct = round(np.random.uniform(10, 90), 1)
            rural_pct = round(100 - urban_pct, 1)
            male_pop = round(population * np.random.uniform(0.48, 0.52), 2)
            female_pop = round(population - male_pop, 2)
            child_pct = round(np.random.uniform(10, 30), 1)
            elderly_pct = round(np.random.uniform(5, 15), 1)
            households = np.random.randint(10000, 500000)
            avg_hh_size = round(np.random.uniform(3.5, 6.5), 1)
            # Underserved: food_supply < 200 MT per million people
            underserved = food_supply < population * 200
            rows.append({
                'State': state,
                'District': f"{state[:4]}_D{d:02d}",
                'Population_M': population,
                'Male_Population_M': male_pop,
                'Female_Population_M': female_pop,
                'Food_Supply_MT': food_supply,
                'BPL_Percentage': bpl_pct,
                'Literacy_Rate': literacy,
                'Urban_Percentage': urban_pct,
                'Rural_Percentage': rural_pct,
                'Child_Population_Pct': child_pct,
                'Elderly_Population_Pct': elderly_pct,
                'Households': households,
                'Avg_Household_Size': avg_hh_size,
                'Underserved': underserved,
            })
    df = pd.DataFrame(rows)
    return df


# ── Aggregated (state-level) helpers used by charts ──────────────────────────

def get_pds_state(pds_df):
    return pds_df.groupby('State').agg(
        Allocated_MT=('Allocated_MT', 'sum'),
        Distributed_MT=('Distributed_MT', 'sum'),
        Population_M=('Population_M', 'sum'),
        BPL_Percentage=('BPL_Percentage', 'mean'),
        Surplus_Deficit=('Surplus_Deficit', 'sum'),
        Per_Capita_kg=('Per_Capita_kg', 'mean'),
    ).reset_index()


def get_census_state(census_df):
    return census_df.groupby('State').agg(
        Population_M=('Population_M', 'sum'),
        Food_Supply_MT=('Food_Supply_MT', 'sum'),
        BPL_Percentage=('BPL_Percentage', 'mean'),
        Underserved=('Underserved', 'any'),
    ).reset_index()


def get_fci_yearly(fci_df):
    return fci_df.groupby('Year').agg(
        Stock_MT=('Stock_MT', 'mean'),
        Wastage_MT=('Wastage_MT', 'sum'),
        Wastage_Pct=('Wastage_Pct', 'mean'),
        Storage_Capacity_MT=('Storage_Capacity_MT', 'mean'),
        Procurement_MT=('Procurement_MT', 'sum'),
        Offtake_MT=('Offtake_MT', 'sum'),
    ).reset_index()


# ── Data cleaning ─────────────────────────────────────────────────────────────

def clean_dataframe(df):
    df = df.drop_duplicates()
    df.columns = [c.strip().replace(' ', '_') for c in df.columns]
    for col in df.select_dtypes(include=[np.number]).columns:
        df[col] = df[col].fillna(df[col].median())
    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Unknown')
    return df


def merge_pds_census(pds_df, census_df):
    pds_s = get_pds_state(pds_df).drop(columns=['BPL_Percentage'])
    cen_s = get_census_state(census_df)
    cen_s = cen_s[['State', 'Population_M', 'Food_Supply_MT', 'BPL_Percentage', 'Underserved']]
    cen_s = cen_s.rename(columns={'Population_M': 'Population_M_cen'})
    return pd.merge(pds_s, cen_s, on='State', how='left')


# ── Summary statistics ────────────────────────────────────────────────────────

def get_summary_stats(df):
    numeric = df.select_dtypes(include=[np.number])
    return {
        col: {
            'mean': round(float(numeric[col].mean()), 2),
            'median': round(float(numeric[col].median()), 2),
            'std': round(float(numeric[col].std()), 2),
            'min': round(float(numeric[col].min()), 2),
            'max': round(float(numeric[col].max()), 2),
        }
        for col in numeric.columns
    }


# ── Charts ────────────────────────────────────────────────────────────────────

def chart_food_allocation(pds_df, state_filter=None):
    df = get_pds_state(pds_df)
    if state_filter:
        df = df[df['State'].isin(state_filter)]
    df = df.sort_values('Allocated_MT', ascending=False).head(15)

    fig, ax = plt.subplots(figsize=(13, 5), facecolor=BG)
    ax.set_facecolor(BG)
    x = np.arange(len(df))
    w = 0.38
    ax.bar(x - w/2, df['Allocated_MT'], w, label='Allocated (MT)', color=BLUE, alpha=0.88)
    bars2 = ax.bar(x + w/2, df['Distributed_MT'], w, label='Distributed (MT)', color=LIGHT_BLUE, alpha=0.88)

    for i, (_, row) in enumerate(df.iterrows()):
        c = GREEN if row['Surplus_Deficit'] >= 0 else RED
        ax.bar(x[i] + w/2, row['Distributed_MT'], w, color=c, alpha=0.45)

    ax.set_xticks(x)
    ax.set_xticklabels(df['State'], rotation=35, ha='right', fontsize=8)
    ax.set_ylabel('Metric Tonnes (MT)', fontsize=10)
    ax.set_title('Food Grain Allocation vs Distribution by State', fontsize=13, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, _: f'{int(v):,}'))
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_population_vs_supply(pds_df, census_df, chart_type='scatter', state_filter=None, bpl_min=0, bpl_max=100):
    pds_s = get_pds_state(pds_df)
    cen_s = get_census_state(census_df)
    merged = pd.merge(pds_s, cen_s, on='State', how='inner', suffixes=('_pds', '_cen'))
    pop_col = 'Population_M_cen' if 'Population_M_cen' in merged.columns else 'Population_M'
    bpl_col = 'BPL_Percentage_cen' if 'BPL_Percentage_cen' in merged.columns else (
        'BPL_Percentage_pds' if 'BPL_Percentage_pds' in merged.columns else 'BPL_Percentage'
    )

    # Normalize merged column names for chart logic
    merged['BPL_Percentage'] = merged[bpl_col]

    # Apply filters
    if state_filter:
        merged = merged[merged['State'].isin(state_filter)]
    merged = merged[(merged['BPL_Percentage'] >= bpl_min) & (merged['BPL_Percentage'] <= bpl_max)]

    if merged.empty:
        fig, ax = plt.subplots(figsize=(9, 4), facecolor=BG)
        ax.text(0.5, 0.5, 'No data for selected filters', ha='center', va='center', fontsize=12)
        return _fig_to_b64(fig)

    served = merged[~merged['Underserved']]
    under  = merged[merged['Underserved']]

    fig, ax = plt.subplots(figsize=(12, 5), facecolor=BG)
    ax.set_facecolor(BG)

    if chart_type == 'scatter':
        ax.scatter(served[pop_col], served['Distributed_MT'], color=BLUE, s=90, alpha=0.85, label=f'Adequate ({len(served)})', zorder=3)
        ax.scatter(under[pop_col],  under['Distributed_MT'],  color=RED,  s=110, marker='^', alpha=0.9, label=f'Under-served ({len(under)})', zorder=4)
        for _, row in merged.iterrows():
            ax.annotate(row['State'], (row[pop_col], row['Distributed_MT']),
                        fontsize=6.5, alpha=0.8, xytext=(3,3), textcoords='offset points')
        x_line = np.linspace(merged[pop_col].min(), merged[pop_col].max(), 100)
        ax.plot(x_line, x_line * 20, '--', color=ORANGE, linewidth=1.5, label='Ideal Supply Line', alpha=0.8)
        ax.set_xlabel('Population (Millions)', fontsize=10)
        ax.set_ylabel('Food Distributed (MT)', fontsize=10)
        ax.set_title('Population vs Food Supply — Scatter Plot', fontsize=13, fontweight='bold', color='#1a237e')

    elif chart_type == 'bar':
        merged_s = merged.sort_values('Food_Supply_MT', ascending=False)
        x = np.arange(len(merged_s))
        w = 0.38
        ax.bar(x - w/2, merged_s[pop_col] * 200, w, label='Required Supply (MT)', color=ORANGE, alpha=0.8)
        ax.bar(x + w/2, merged_s['Food_Supply_MT'], w, label='Actual Supply (MT)', color=BLUE, alpha=0.8)
        ax.set_xticks(x)
        ax.set_xticklabels(merged_s['State'], rotation=35, ha='right', fontsize=8)
        ax.set_ylabel('Food Supply (MT)', fontsize=10)
        ax.set_title('Required vs Actual Food Supply by State', fontsize=13, fontweight='bold', color='#1a237e')
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'{int(v):,}'))

    elif chart_type == 'bpl':
        merged_s = merged.sort_values('BPL_Percentage', ascending=False)
        fig_height = max(9, len(merged_s) * 0.28)
        fig, ax = plt.subplots(figsize=(12, fig_height), facecolor=BG)
        ax.set_facecolor(BG)
        colors = [RED if u else GREEN for u in merged_s['Underserved']]
        ax.barh(merged_s['State'], merged_s['BPL_Percentage'], color=colors, alpha=0.85)
        ax.invert_yaxis()
        ax.set_xlabel('BPL Population %', fontsize=10)
        ax.set_title('BPL Percentage by State (Red = Under-served)', fontsize=13, fontweight='bold', color='#1a237e')
        ax.axvline(x=merged_s['BPL_Percentage'].mean(), color=ORANGE, linestyle='--', linewidth=1.5, label=f'Avg: {merged_s["BPL_Percentage"].mean():.1f}%')
        ax.legend(fontsize=9)
        ax.tick_params(axis='y', labelsize=8)
        fig.tight_layout()

    elif chart_type == 'percapita':
        merged['Per_Capita_Supply'] = merged['Food_Supply_MT'] / (merged[pop_col] * 1e6) * 1000
        merged_s = merged.sort_values('Per_Capita_Supply', ascending=False)
        colors = [GREEN if v >= 0.2 else RED for v in merged_s['Per_Capita_Supply']]
        ax.bar(range(len(merged_s)), merged_s['Per_Capita_Supply'], color=colors, alpha=0.85)
        ax.set_xticks(range(len(merged_s)))
        ax.set_xticklabels(merged_s['State'], rotation=35, ha='right', fontsize=8)
        ax.axhline(y=0.2, color=ORANGE, linestyle='--', linewidth=1.5, label='Min Required (0.2 kg/person)')
        ax.set_ylabel('Per Capita Supply (kg/person)', fontsize=10)
        ax.set_title('Per Capita Food Supply by State', fontsize=13, fontweight='bold', color='#1a237e')
        ax.legend(fontsize=9)

    ax.legend(fontsize=9)
    ax.grid(linestyle='--', alpha=0.35)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_wastage_trends(fci_df):
    df = get_fci_yearly(fci_df)

    fig, ax1 = plt.subplots(figsize=(11, 5), facecolor=BG)
    ax1.set_facecolor(BG)
    ax1.plot(df['Year'], df['Stock_MT'], color=BLUE, marker='o', linewidth=2, markersize=6, label='Avg Stock (MT)')
    ax1.fill_between(df['Year'], df['Stock_MT'], alpha=0.12, color=BLUE)
    ax1.set_xlabel('Year', fontsize=10)
    ax1.set_ylabel('Stock (MT)', fontsize=10, color=BLUE)
    ax1.tick_params(axis='y', labelcolor=BLUE)

    ax2 = ax1.twinx()
    ax2.bar(df['Year'], df['Wastage_MT'], color=RED, alpha=0.45, label='Total Wastage (MT)', width=0.5)
    ax2.set_ylabel('Wastage (MT)', fontsize=10, color=RED)
    ax2.tick_params(axis='y', labelcolor=RED)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=9, loc='upper left')
    ax1.set_title('FCI Stock Levels & Storage Wastage Trends (2015–2024)', fontsize=13, fontweight='bold', color='#1a237e')
    ax1.grid(axis='y', linestyle='--', alpha=0.35)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_predictive_demand(fci_df):
    df = get_fci_yearly(fci_df)
    years = df['Year'].values
    demand = df['Stock_MT'].values

    coeffs = np.polyfit(years, demand, 1)
    poly = np.poly1d(coeffs)
    future_years = np.arange(years[-1] + 1, years[-1] + 7)
    all_years = np.concatenate([years, future_years])
    sigma = (demand - poly(years)).std()

    fig, ax = plt.subplots(figsize=(11, 5), facecolor=BG)
    ax.set_facecolor(BG)
    ax.plot(years, demand, color=BLUE, marker='o', linewidth=2, markersize=6, label='Historical Stock')
    ax.plot(all_years, poly(all_years), '--', color=ORANGE, linewidth=2, label='Trend Line')
    ax.plot(future_years, poly(future_years), color=GREEN, marker='s', linewidth=2, markersize=7, label='Forecast (2025–2030)')
    ax.fill_between(future_years, poly(future_years) - sigma, poly(future_years) + sigma,
                    color=GREEN, alpha=0.15, label='Confidence Band')
    ax.set_xlabel('Year', fontsize=10)
    ax.set_ylabel('Food Demand (MT)', fontsize=10)
    ax.set_title('Predictive Food Demand Forecast (NumPy Linear Regression)', fontsize=13, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.grid(linestyle='--', alpha=0.35)
    fig.tight_layout()
    return _fig_to_b64(fig)


# ── CSV upload processing ─────────────────────────────────────────────────────

def process_uploaded_csv(file_path):
    try:
        df = pd.read_csv(file_path)
    except Exception as e:
        return None, f"Could not read CSV: {e}"
    if df.empty:
        return None, "The uploaded file is empty."
    if len(df.columns) < 2:
        return None, "CSV must have at least 2 columns."
    df = clean_dataframe(df)
    return df, ""


# ── OGD (Open Government Data) Dataset ───────────────────────────────────────

OGD_SCHEMES = [
    'PMGSY','MGNREGA','PM-KISAN','PMAY','Swachh Bharat','Jal Jeevan Mission',
    'Ayushman Bharat','PMFBY','NFSA','Mid-Day Meal','ICDS','NSAP',
    'PM Ujjwala','PMJDY','Skill India',
]

def get_ogd_data():
    """OGD scheme-wise state dataset — 1080 rows × 16 columns."""
    np.random.seed(55)
    rows = []
    for state in STATES:
        for scheme in OGD_SCHEMES:
            for year in [2021, 2022, 2023]:
                budget     = round(np.random.uniform(50, 5000), 2)
                spent      = round(budget * np.random.uniform(0.50, 0.98), 2)
                beneficiaries = np.random.randint(1000, 500000)
                target     = np.random.randint(5000, 600000)
                achievement_pct = round(min(beneficiaries / target * 100, 100), 1)
                male_ben   = np.random.randint(500, 250000)
                female_ben = beneficiaries - male_ben
                rural_ben  = np.random.randint(500, 400000)
                urban_ben  = beneficiaries - rural_ben
                sc_ben     = np.random.randint(100, 100000)
                st_ben     = np.random.randint(100, 80000)
                complaints = np.random.randint(0, 500)
                resolved   = np.random.randint(0, complaints + 1)
                rows.append({
                    'State':            state,
                    'Scheme':           scheme,
                    'Year':             year,
                    'Budget_Cr':        budget,
                    'Spent_Cr':         spent,
                    'Utilisation_Pct':  round(spent / budget * 100, 1),
                    'Beneficiaries':    beneficiaries,
                    'Target':           target,
                    'Achievement_Pct':  achievement_pct,
                    'Male_Ben':         male_ben,
                    'Female_Ben':       female_ben,
                    'Rural_Ben':        rural_ben,
                    'Urban_Ben':        urban_ben,
                    'SC_Ben':           sc_ben,
                    'ST_Ben':           st_ben,
                    'Complaints':       complaints,
                    'Resolved':         resolved,
                })
    return pd.DataFrame(rows)


def chart_ogd_budget(df):
    grp = df.groupby('Scheme').agg(Budget=('Budget_Cr','sum'), Spent=('Spent_Cr','sum')).reset_index()
    grp = grp.sort_values('Budget', ascending=False)
    x = np.arange(len(grp)); w = 0.38
    fig, ax = plt.subplots(figsize=(13, 5), facecolor=BG)
    ax.set_facecolor(BG)
    ax.bar(x - w/2, grp['Budget'], w, label='Budget (Cr)', color=BLUE, alpha=0.85)
    ax.bar(x + w/2, grp['Spent'],  w, label='Spent (Cr)',  color=GREEN, alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(grp['Scheme'], rotation=35, ha='right', fontsize=8)
    ax.set_ylabel('Amount (Crore ₹)', fontsize=10)
    ax.set_title('Scheme-wise Budget vs Expenditure', fontsize=13, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'{int(v):,}'))
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_ogd_achievement(df):
    grp = df.groupby('State')['Achievement_Pct'].mean().sort_values(ascending=True).tail(20)
    colors = [GREEN if v >= 75 else ORANGE if v >= 50 else RED for v in grp.values]
    fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG)
    ax.set_facecolor(BG)
    ax.barh(grp.index, grp.values, color=colors, alpha=0.88)
    ax.axvline(x=75, color=BLUE, linestyle='--', linewidth=1.5, label='75% Target')
    ax.set_xlabel('Avg Achievement %', fontsize=10)
    ax.set_title('State-wise Scheme Achievement %', fontsize=13, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.grid(axis='x', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_ogd_beneficiaries(df):
    grp = df.groupby('Scheme')['Beneficiaries'].sum().sort_values(ascending=False)
    colors = plt.cm.Blues(np.linspace(0.4, 0.9, len(grp)))
    fig, ax = plt.subplots(figsize=(11, 5), facecolor=BG)
    ax.set_facecolor(BG)
    ax.bar(range(len(grp)), grp.values, color=colors, alpha=0.9)
    ax.set_xticks(range(len(grp)))
    ax.set_xticklabels(grp.index, rotation=35, ha='right', fontsize=8)
    ax.set_ylabel('Total Beneficiaries', fontsize=10)
    ax.set_title('Total Beneficiaries by Scheme', fontsize=13, fontweight='bold', color='#1a237e')
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'{int(v):,}'))
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_ogd_gender(df):
    grp = df.groupby('Scheme').agg(Male=('Male_Ben','sum'), Female=('Female_Ben','sum')).reset_index()
    grp = grp.sort_values('Male', ascending=False)
    x = np.arange(len(grp)); w = 0.38
    fig, ax = plt.subplots(figsize=(13, 5), facecolor=BG)
    ax.set_facecolor(BG)
    ax.bar(x - w/2, grp['Male'],   w, label='Male',   color=BLUE,   alpha=0.85)
    ax.bar(x + w/2, grp['Female'], w, label='Female', color=PURPLE, alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(grp['Scheme'], rotation=35, ha='right', fontsize=8)
    ax.set_ylabel('Beneficiaries', fontsize=10)
    ax.set_title('Gender-wise Beneficiaries by Scheme', fontsize=13, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'{int(v):,}'))
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_ogd_utilisation_trend(df):
    grp = df.groupby(['Year','Scheme'])['Utilisation_Pct'].mean().unstack(fill_value=0)
    fig, ax = plt.subplots(figsize=(11, 5), facecolor=BG)
    ax.set_facecolor(BG)
    colors = plt.cm.tab20(np.linspace(0, 1, len(grp.columns)))
    for col, color in zip(grp.columns, colors):
        ax.plot(grp.index, grp[col], marker='o', linewidth=1.8, markersize=5, label=col, color=color)
    ax.set_xlabel('Year', fontsize=10)
    ax.set_ylabel('Avg Utilisation %', fontsize=10)
    ax.set_title('Budget Utilisation Trend by Scheme (Year-wise)', fontsize=13, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=7, ncol=3, loc='lower right')
    ax.grid(linestyle='--', alpha=0.35)
    fig.tight_layout()
    return _fig_to_b64(fig)
