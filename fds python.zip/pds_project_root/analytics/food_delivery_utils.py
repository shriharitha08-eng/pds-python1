"""
Zomato & Swiggy India dataset generator + chart utilities.
1000+ rows, 15+ columns, dynamic filtering support.
"""
import io, base64
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

BG = '#f8faff'
ZOMATO_RED   = '#e23744'
SWIGGY_ORG   = '#fc8019'
BLUE         = '#1a73e8'
GREEN        = '#43a047'
PURPLE       = '#8e24aa'

CITIES = [
    'Mumbai','Delhi','Bangalore','Hyderabad','Chennai','Kolkata','Pune',
    'Ahmedabad','Jaipur','Surat','Lucknow','Kanpur','Nagpur','Indore',
    'Bhopal','Visakhapatnam','Patna','Vadodara','Ghaziabad','Ludhiana',
    'Agra','Nashik','Faridabad','Meerut','Rajkot','Varanasi','Srinagar',
    'Aurangabad','Dhanbad','Amritsar','Allahabad','Ranchi','Howrah','Coimbatore',
    'Jabalpur','Gwalior','Vijayawada','Jodhpur','Madurai','Raipur',
]

CUISINES = ['North Indian','South Indian','Chinese','Fast Food','Pizza','Biryani',
            'Mughlai','Continental','Italian','Mexican','Thai','Seafood','Desserts','Cafe']

CATEGORIES = ['Restaurant','Cloud Kitchen','Bakery','Cafe','Street Food','Fine Dining']

PLATFORMS = ['Zomato', 'Swiggy']

def _fig_to_b64(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight', dpi=110, facecolor=BG)
    buf.seek(0)
    enc = base64.b64encode(buf.read()).decode('utf-8')
    plt.close(fig)
    return enc


def get_food_delivery_data():
    """Generate 1200-row × 18-column Zomato+Swiggy dataset."""
    np.random.seed(99)
    rows = []
    for i in range(1200):
        platform   = np.random.choice(PLATFORMS)
        city       = np.random.choice(CITIES)
        cuisine    = np.random.choice(CUISINES)
        category   = np.random.choice(CATEGORIES)
        year       = np.random.choice([2021, 2022, 2023, 2024])
        month      = np.random.randint(1, 13)
        rating     = round(np.random.uniform(2.5, 5.0), 1)
        orders     = np.random.randint(100, 15000)
        avg_order  = round(np.random.uniform(150, 900), 2)
        revenue    = round(orders * avg_order, 2)
        delivery_t = round(np.random.uniform(15, 65), 1)
        discount   = round(np.random.uniform(0, 40), 1)
        cancelled  = round(np.random.uniform(1, 15), 1)
        new_users  = np.random.randint(50, 5000)
        repeat_pct = round(np.random.uniform(20, 80), 1)
        commission = round(revenue * np.random.uniform(0.18, 0.30), 2)
        active_res = np.random.randint(50, 3000)
        rows.append({
            'Platform':          platform,
            'City':              city,
            'Cuisine':           cuisine,
            'Category':          category,
            'Year':              year,
            'Month':             month,
            'Rating':            rating,
            'Orders':            orders,
            'Avg_Order_Value':   avg_order,
            'Revenue_INR':       revenue,
            'Delivery_Time_Min': delivery_t,
            'Discount_Pct':      discount,
            'Cancellation_Pct':  cancelled,
            'New_Users':         new_users,
            'Repeat_Customer_Pct': repeat_pct,
            'Commission_INR':    commission,
            'Active_Restaurants': active_res,
            'Net_Revenue_INR':   round(revenue - commission, 2),
        })
    return pd.DataFrame(rows)


# ── Chart functions ───────────────────────────────────────────────────────────

def chart_platform_revenue(df):
    grp = df.groupby('Platform')['Revenue_INR'].sum().reset_index()
    colors = [ZOMATO_RED if p == 'Zomato' else SWIGGY_ORG for p in grp['Platform']]
    fig, ax = plt.subplots(figsize=(7, 4), facecolor=BG)
    ax.set_facecolor(BG)
    bars = ax.bar(grp['Platform'], grp['Revenue_INR'] / 1e7, color=colors, width=0.4, alpha=0.9)
    for bar in bars:
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                f'₹{bar.get_height():.1f}Cr', ha='center', fontsize=10, fontweight='bold')
    ax.set_ylabel('Revenue (Crore ₹)', fontsize=10)
    ax.set_title('Total Revenue: Zomato vs Swiggy', fontsize=12, fontweight='bold', color='#1a237e')
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_city_orders(df, top_n=15):
    grp = df.groupby(['City','Platform'])['Orders'].sum().unstack(fill_value=0).reset_index()
    grp['Total'] = grp.get('Zomato', 0) + grp.get('Swiggy', 0)
    grp = grp.nlargest(top_n, 'Total')
    x = np.arange(len(grp))
    w = 0.38
    fig, ax = plt.subplots(figsize=(13, 5), facecolor=BG)
    ax.set_facecolor(BG)
    if 'Zomato' in grp.columns:
        ax.bar(x - w/2, grp['Zomato'], w, label='Zomato', color=ZOMATO_RED, alpha=0.85)
    if 'Swiggy' in grp.columns:
        ax.bar(x + w/2, grp['Swiggy'], w, label='Swiggy', color=SWIGGY_ORG, alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(grp['City'], rotation=35, ha='right', fontsize=8)
    ax.set_ylabel('Total Orders', fontsize=10)
    ax.set_title(f'Top {top_n} Cities by Orders', fontsize=12, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: f'{int(v):,}'))
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_cuisine_popularity(df):
    grp = df.groupby('Cuisine')['Orders'].sum().sort_values(ascending=True).tail(12)
    colors = plt.cm.RdYlGn(np.linspace(0.3, 0.9, len(grp)))
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=BG)
    ax.set_facecolor(BG)
    bars = ax.barh(grp.index, grp.values, color=colors, alpha=0.88)
    for bar in bars:
        ax.text(bar.get_width() + 100, bar.get_y() + bar.get_height()/2,
                f'{int(bar.get_width()):,}', va='center', fontsize=8)
    ax.set_xlabel('Total Orders', fontsize=10)
    ax.set_title('Cuisine Popularity by Orders', fontsize=12, fontweight='bold', color='#1a237e')
    ax.grid(axis='x', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_monthly_trend(df):
    grp = df.groupby(['Year','Month','Platform'])['Orders'].sum().reset_index()
    grp['Period'] = grp['Year'].astype(str) + '-' + grp['Month'].astype(str).str.zfill(2)
    grp = grp.sort_values(['Year','Month'])
    fig, ax = plt.subplots(figsize=(13, 5), facecolor=BG)
    ax.set_facecolor(BG)
    for platform, color in [('Zomato', ZOMATO_RED), ('Swiggy', SWIGGY_ORG)]:
        sub = grp[grp['Platform'] == platform]
        periods = sub['Period'].tolist()
        ax.plot(range(len(periods)), sub['Orders'].values, color=color,
                marker='o', markersize=4, linewidth=2, label=platform, alpha=0.9)
    ticks = grp[grp['Platform'] == 'Zomato']['Period'].tolist()
    step = max(1, len(ticks)//12)
    ax.set_xticks(range(0, len(ticks), step))
    ax.set_xticklabels(ticks[::step], rotation=35, ha='right', fontsize=7)
    ax.set_ylabel('Total Orders', fontsize=10)
    ax.set_title('Monthly Order Trend — Zomato vs Swiggy', fontsize=12, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.grid(linestyle='--', alpha=0.35)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_rating_distribution(df):
    fig, ax = plt.subplots(figsize=(9, 4), facecolor=BG)
    ax.set_facecolor(BG)
    for platform, color in [('Zomato', ZOMATO_RED), ('Swiggy', SWIGGY_ORG)]:
        sub = df[df['Platform'] == platform]['Rating']
        ax.hist(sub, bins=20, color=color, alpha=0.6, label=platform, edgecolor='white')
    ax.set_xlabel('Rating', fontsize=10)
    ax.set_ylabel('Count', fontsize=10)
    ax.set_title('Rating Distribution — Zomato vs Swiggy', fontsize=12, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)


def chart_delivery_time(df):
    grp = df.groupby(['City','Platform'])['Delivery_Time_Min'].mean().unstack(fill_value=0)
    grp['Avg'] = grp.mean(axis=1)
    grp = grp.nlargest(15, 'Avg').drop(columns='Avg')
    x = np.arange(len(grp))
    w = 0.38
    fig, ax = plt.subplots(figsize=(13, 5), facecolor=BG)
    ax.set_facecolor(BG)
    if 'Zomato' in grp.columns:
        ax.bar(x - w/2, grp['Zomato'], w, label='Zomato', color=ZOMATO_RED, alpha=0.85)
    if 'Swiggy' in grp.columns:
        ax.bar(x + w/2, grp['Swiggy'], w, label='Swiggy', color=SWIGGY_ORG, alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(grp.index, rotation=35, ha='right', fontsize=8)
    ax.set_ylabel('Avg Delivery Time (min)', fontsize=10)
    ax.set_title('Average Delivery Time by City', fontsize=12, fontweight='bold', color='#1a237e')
    ax.legend(fontsize=9)
    ax.grid(axis='y', linestyle='--', alpha=0.4)
    fig.tight_layout()
    return _fig_to_b64(fig)
