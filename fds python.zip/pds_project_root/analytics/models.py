"""
Models for Food Distribution & PDS Analysis System.
Defines UserProfile (role-based) and UploadedDataset.
"""
from django.db import models
from django.contrib.auth.models import User


class UserProfile(models.Model):
    ROLE_CHOICES = [('admin', 'Admin'), ('user', 'User')]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='user')

    def __str__(self):
        return f"{self.user.username} ({self.role})"

    def is_admin(self):
        return self.role == 'admin'


class UploadedDataset(models.Model):
    DATASET_TYPES = [
        ('pds', 'PDS Data'),
        ('fci', 'FCI Stock Data'),
        ('census', 'Census Population Data'),
        ('wastage', 'Wastage & Storage Data'),
    ]
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    dataset_type = models.CharField(max_length=20, choices=DATASET_TYPES)
    original_file = models.FileField(upload_to='uploads/')
    processed_file = models.FileField(upload_to='uploads/processed/', blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    row_count = models.IntegerField(default=0)
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.dataset_type} - {self.uploaded_at.strftime('%Y-%m-%d')}"
