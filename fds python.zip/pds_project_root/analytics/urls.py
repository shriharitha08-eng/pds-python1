"""URL patterns for the analytics app."""
from django.urls import path
from . import views

urlpatterns = [
    path('',                            views.home,                    name='home'),
    path('login/',                      views.login_view,              name='login'),
    path('signup/',                     views.signup_view,             name='signup'),
    path('logout/',                     views.logout_view,             name='logout'),
    path('dashboard/',                  views.dashboard,               name='dashboard'),
    path('dashboard/allocation/',       views.dashboard_allocation,    name='dash_allocation'),
    path('dashboard/population/',       views.dashboard_population,    name='dash_population'),
    path('dashboard/wastage/',          views.dashboard_wastage,       name='dash_wastage'),
    path('dashboard/predictive/',       views.dashboard_predictive,    name='dash_predictive'),
    path('dashboard/food-delivery/',    views.dashboard_food_delivery, name='dash_food_delivery'),
    path('upload/',                     views.upload_dataset,          name='upload_dataset'),
    path('download/<str:report_type>/', views.download_report,         name='download_report'),
]
