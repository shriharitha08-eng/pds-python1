"""
Views for Food Distribution & PDS Analysis System + Zomato/Swiggy Dashboard.
"""
import os
import numpy as np
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse

from .models import UserProfile, UploadedDataset
from .data_utils import (
    get_pds_data, get_fci_data, get_census_data,
    get_pds_state, get_census_state, get_fci_yearly,
    merge_pds_census, get_summary_stats,
    chart_food_allocation, chart_population_vs_supply,
    chart_wastage_trends, chart_predictive_demand,
    process_uploaded_csv,
    get_ogd_data, chart_ogd_budget, chart_ogd_achievement,
    chart_ogd_beneficiaries, chart_ogd_gender, chart_ogd_utilisation_trend,
)
import io, base64

from .food_delivery_utils import (
    get_food_delivery_data,
    chart_platform_revenue, chart_city_orders, chart_cuisine_popularity,
    chart_monthly_trend, chart_rating_distribution, chart_delivery_time,
)


def _get_role(user):
    try:
        return user.profile.role
    except UserProfile.DoesNotExist:
        return 'user'


def _require_admin(request):
    if _get_role(request.user) != 'admin':
        messages.error(request, "Admin access required.")
        return False
    return True


# ── Public ────────────────────────────────────────────────────────────────────

def home(request):
    return render(request, 'analytics/home.html')


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        user = authenticate(request,
                            username=request.POST.get('username', '').strip(),
                            password=request.POST.get('password', ''))
        if user:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, "Invalid username or password.")
    return render(request, 'analytics/login.html')


def signup_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        email    = request.POST.get('email', '').strip()
        p1       = request.POST.get('password1', '')
        p2       = request.POST.get('password2', '')
        role     = request.POST.get('role', 'user')
        if p1 != p2:
            messages.error(request, "Passwords do not match.")
        elif User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken.")
        elif len(p1) < 6:
            messages.error(request, "Password must be at least 6 characters.")
        else:
            user = User.objects.create_user(username=username, email=email, password=p1)
            UserProfile.objects.create(user=user, role=role)
            login(request, user)
            messages.success(request, f"Welcome, {username}!")
            return redirect('dashboard')
    return render(request, 'analytics/signup.html')


def logout_view(request):
    logout(request)
    return redirect('home')


# ── Overview Dashboard ────────────────────────────────────────────────────────

@login_required
def dashboard(request):
    pds_df    = get_pds_data()
    fci_df    = get_fci_data()
    census_df = get_census_data()
    food_df   = get_food_delivery_data()

    total_allocated   = int(pds_df['Allocated_MT'].sum())
    total_distributed = int(pds_df['Distributed_MT'].sum())
    total_wastage     = round(float(fci_df['Wastage_MT'].sum()), 1)
    underserved_count = int(census_df['Underserved'].sum())
    efficiency        = round(total_distributed / total_allocated * 100, 1)
    food_orders       = int(food_df['Orders'].sum())

    ctx = {
        'role':              _get_role(request.user),
        'total_allocated':   f"{total_allocated:,}",
        'total_distributed': f"{total_distributed:,}",
        'total_wastage':     total_wastage,
        'underserved_count': underserved_count,
        'efficiency':        efficiency,
        'food_orders':       f"{food_orders:,}",
        'recent_uploads':    UploadedDataset.objects.order_by('-uploaded_at')[:5],
    }
    return render(request, 'analytics/dashboard.html', ctx)


# ── Dashboard 1: Food Allocation ──────────────────────────────────────────────

@login_required
def dashboard_allocation(request):
    pds_df       = get_pds_data()
    state_filter = request.GET.getlist('state')
    all_states   = sorted(pds_df['State'].unique().tolist())
    chart        = chart_food_allocation(pds_df, state_filter if state_filter else None)
    state_df     = get_pds_state(pds_df)
    stats        = get_summary_stats(state_df)
    surplus_states = state_df[state_df['Surplus_Deficit'] > 0]['State'].tolist()
    deficit_states = state_df[state_df['Surplus_Deficit'] <= 0]['State'].tolist()
    ctx = {
        'role':            _get_role(request.user),
        'chart':           chart,
        'stats':           stats,
        'all_states':      all_states,
        'selected_states': state_filter,
        'surplus_states':  surplus_states,
        'deficit_states':  deficit_states,
        'table_data':      state_df.to_dict('records'),
    }
    return render(request, 'analytics/dash_allocation.html', ctx)


# ── Dashboard 2: Population vs Supply ────────────────────────────────────────

@login_required
def dashboard_population(request):
    pds_df    = get_pds_data()
    census_df = get_census_data()

    state_filter = request.GET.getlist('state')
    bpl_min      = float(request.GET.get('bpl_min', 0))
    bpl_max      = float(request.GET.get('bpl_max', 100))
    chart_type   = request.GET.get('chart', 'scatter')

    chart  = chart_population_vs_supply(pds_df, census_df, chart_type,
                                        state_filter if state_filter else None,
                                        bpl_min, bpl_max)
    merged    = merge_pds_census(pds_df, census_df)
    cen_state = get_census_state(census_df)
    stats     = get_summary_stats(cen_state)
    underserved = cen_state[cen_state['Underserved']]['State'].tolist()
    adequate    = cen_state[~cen_state['Underserved']]['State'].tolist()
    all_states  = sorted(cen_state['State'].tolist())

    table_df = merged.copy()
    if state_filter:
        table_df = table_df[table_df['State'].isin(state_filter)]
    table_df = table_df[(table_df['BPL_Percentage'] >= bpl_min) & (table_df['BPL_Percentage'] <= bpl_max)]

    ctx = {
        'role':         _get_role(request.user),
        'chart':        chart,
        'chart_type':   chart_type,
        'stats':        stats,
        'table_data':   table_df.to_dict('records'),
        'underserved':  underserved,
        'adequate':     adequate,
        'all_states':   all_states,
        'state_filter': state_filter,
        'bpl_min':      bpl_min,
        'bpl_max':      bpl_max,
    }
    return render(request, 'analytics/dash_population.html', ctx)


# ── Dashboard 3: Wastage & Storage ───────────────────────────────────────────

@login_required
def dashboard_wastage(request):
    fci_df      = get_fci_data()
    year_filter = request.GET.get('year')
    if year_filter:
        fci_df = fci_df[fci_df['Year'] >= int(year_filter)]
    chart  = chart_wastage_trends(fci_df)
    yearly = get_fci_yearly(fci_df)
    stats  = get_summary_stats(yearly)
    ctx = {
        'role':          _get_role(request.user),
        'chart':         chart,
        'stats':         stats,
        'table_data':    yearly.to_dict('records'),
        'years':         list(range(2015, 2025)),
        'selected_year': year_filter,
    }
    return render(request, 'analytics/dash_wastage.html', ctx)


# ── Dashboard 4: Predictive Insights ─────────────────────────────────────────

@login_required
def dashboard_predictive(request):
    fci_df = get_fci_data()
    chart  = chart_predictive_demand(fci_df)
    yearly = get_fci_yearly(fci_df)
    years  = yearly['Year'].values
    demand = yearly['Stock_MT'].values
    coeffs = np.polyfit(years, demand, 1)
    poly   = np.poly1d(coeffs)
    forecast = [{'year': y, 'demand': round(float(poly(y)), 2)} for y in range(2025, 2031)]
    ctx = {
        'role':      _get_role(request.user),
        'chart':     chart,
        'forecast':  forecast,
        'slope':     round(float(coeffs[0]), 3),
        'intercept': round(float(coeffs[1]), 1),
    }
    return render(request, 'analytics/dash_predictive.html', ctx)


# ── Dashboard 5: Zomato & Swiggy ─────────────────────────────────────────────

@login_required
def dashboard_food_delivery(request):
    df = get_food_delivery_data()

    # Read filters
    platform_f = request.GET.get('platform', '')
    city_f     = request.GET.get('city', '')
    cuisine_f  = request.GET.get('cuisine', '')
    year_f     = request.GET.get('year', '')
    chart_type = request.GET.get('chart', 'revenue')

    # Apply filters
    filtered = df.copy()
    if platform_f: filtered = filtered[filtered['Platform'] == platform_f]
    if city_f:     filtered = filtered[filtered['City'] == city_f]
    if cuisine_f:  filtered = filtered[filtered['Cuisine'] == cuisine_f]
    if year_f:     filtered = filtered[filtered['Year'] == int(year_f)]

    # KPIs
    total_orders    = int(filtered['Orders'].sum())
    total_revenue   = round(float(filtered['Revenue_INR'].sum()) / 1e7, 2)
    avg_rating      = round(float(filtered['Rating'].mean()), 2) if len(filtered) else 0
    avg_delivery    = round(float(filtered['Delivery_Time_Min'].mean()), 1) if len(filtered) else 0
    avg_cancel      = round(float(filtered['Cancellation_Pct'].mean()), 1) if len(filtered) else 0
    total_new_users = int(filtered['New_Users'].sum())

    # Dynamic chart selection
    chart_map = {
        'revenue':  lambda: chart_platform_revenue(filtered),
        'city':     lambda: chart_city_orders(filtered),
        'cuisine':  lambda: chart_cuisine_popularity(filtered),
        'trend':    lambda: chart_monthly_trend(filtered),
        'rating':   lambda: chart_rating_distribution(filtered),
        'delivery': lambda: chart_delivery_time(filtered),
    }
    chart = chart_map.get(chart_type, chart_map['revenue'])()

    # Summary stats
    stats = get_summary_stats(filtered[['Orders','Revenue_INR','Rating',
                                        'Delivery_Time_Min','Discount_Pct',
                                        'Cancellation_Pct','New_Users',
                                        'Repeat_Customer_Pct']])

    table_data = filtered.sort_values('Revenue_INR', ascending=False).head(50).to_dict('records')

    ctx = {
        'role':            _get_role(request.user),
        'total_orders':    f'{total_orders:,}',
        'total_revenue':   total_revenue,
        'avg_rating':      avg_rating,
        'avg_delivery':    avg_delivery,
        'avg_cancel':      avg_cancel,
        'total_new_users': f'{total_new_users:,}',
        'chart':           chart,
        'chart_type':      chart_type,
        'stats':           stats,
        'table_data':      table_data,
        'platforms':       ['Zomato', 'Swiggy'],
        'cities':          sorted(df['City'].unique().tolist()),
        'cuisines':        sorted(df['Cuisine'].unique().tolist()),
        'years':           sorted(df['Year'].unique().tolist()),
        'platform_f':      platform_f,
        'city_f':          city_f,
        'cuisine_f':       cuisine_f,
        'year_f':          year_f,
    }
    return render(request, 'analytics/dash_food_delivery.html', ctx)


# ── File Upload (Admin only) ──────────────────────────────────────────────────

@login_required
def upload_dataset(request):
    if not _require_admin(request):
        return redirect('dashboard')
    if request.method == 'POST':
        dataset_type  = request.POST.get('dataset_type', 'pds')
        uploaded_file = request.FILES.get('csv_file')
        if not uploaded_file:
            messages.error(request, "No file selected.")
            return redirect('upload_dataset')
        if not uploaded_file.name.endswith('.csv'):
            messages.error(request, "Only CSV files are accepted.")
            return redirect('upload_dataset')
        record = UploadedDataset(uploaded_by=request.user,
                                 dataset_type=dataset_type,
                                 original_file=uploaded_file)
        record.save()
        df, error = process_uploaded_csv(record.original_file.path)
        if error:
            record.delete()
            messages.error(request, f"Processing error: {error}")
            return redirect('upload_dataset')
        from django.conf import settings
        processed_name = f"processed/{os.path.basename(record.original_file.path)}"
        processed_path = os.path.join(settings.MEDIA_ROOT, 'uploads', processed_name)
        os.makedirs(os.path.dirname(processed_path), exist_ok=True)
        df.to_csv(processed_path, index=False)
        record.row_count      = len(df)
        record.processed_file = f"uploads/{processed_name}"
        record.save()
        messages.success(request, f"Dataset uploaded and processed: {len(df)} rows.")
        return redirect('upload_dataset')
    uploads = UploadedDataset.objects.order_by('-uploaded_at')
    return render(request, 'analytics/upload.html', {
        'role': _get_role(request.user),
        'uploads': uploads,
    })


# ── CSV Download ──────────────────────────────────────────────────────────────

@login_required
def download_report(request, report_type):
    datasets = {
        'pds':    (get_pds_data,          'pds_allocation_report.csv'),
        'fci':    (get_fci_data,          'fci_wastage_report.csv'),
        'census': (get_census_data,       'census_population_report.csv'),
        'food':   (get_food_delivery_data,'zomato_swiggy_report.csv'),
    }
    if report_type not in datasets:
        messages.error(request, "Invalid report type.")
        return redirect('dashboard')
    getter, filename = datasets[report_type]
    df = getter()
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    df.to_csv(response, index=False)
    return response


